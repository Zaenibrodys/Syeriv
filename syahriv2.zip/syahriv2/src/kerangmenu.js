const kerangmenu = (prefix) => { 
	return `
╔══✪〘 KERANG 〙✪══
║
╰─⊱ *${prefix}apakah [optional]*
╰─⊱ *${prefix}rate [optional]*
╰─⊱ *${prefix}bisakah [optional]*
╰─⊱ *${prefix}kapankah [optional]*
╰─⊱ *${prefix}gantengcek*
╰─⊱ *${prefix}toxic*
╰─⊱ *${prefix}cantikcek*
╰─⊱ *${prefix}persengay*
║
╚═〘  ZEEN BOT 〙`
}
exports.kerangmenu = kerangmenu